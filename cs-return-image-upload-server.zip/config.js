const imageFolder='/var/www/html/salemessage/csreturn';
// const imageFolder='./files';
const imageUrlRoot = 'http://10.1.1.190/salemessage/csreturn';
const port = 53500;

module.exports = {
  port,
  imageFolder,
  imageUrlRoot
};
