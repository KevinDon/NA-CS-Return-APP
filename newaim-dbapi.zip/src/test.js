let data = [0, 1, 2, 3];
let newData = data.filter((e, i) => i != 0);

console.log(newData);