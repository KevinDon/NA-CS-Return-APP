const SaleMessageApiConfig = {
    login:'http://smtwo.test.com/api/index/login',
    tracking: 'http://smtwo.test.com/api/index/tracking',
    historyLog: 'http://smtwo.test.com/api/index/savehistory'
};
export {SaleMessageApiConfig}
